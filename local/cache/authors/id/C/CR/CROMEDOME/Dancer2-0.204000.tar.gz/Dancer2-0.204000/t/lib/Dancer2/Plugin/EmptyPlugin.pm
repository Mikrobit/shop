package Dancer2::Plugin::EmptyPlugin;
use Dancer2::Plugin;

# This plugin does nothing.
# Based on test from @e11it in #510

register_plugin;

1;

